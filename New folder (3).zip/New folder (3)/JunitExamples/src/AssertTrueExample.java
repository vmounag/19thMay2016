import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class AssertTrueExample {

	@Test
	public void assertExample()
	{
		AssertTrue a=new AssertTrue();
		assertTrue(a.additionExample(2,3)==5);
		
	}

}
