
public class AssertTrue {
public static int additionExample(int a,int b)
{
	return a+b;
}
}
