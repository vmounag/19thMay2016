
public class AdditionExample {
 public int add(int a,int b)
 {
	 return a+b;
 }
}
