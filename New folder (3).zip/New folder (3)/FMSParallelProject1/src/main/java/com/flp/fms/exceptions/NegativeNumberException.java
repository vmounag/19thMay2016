package com.flp.fms.exceptions;

public class NegativeNumberException extends Exception {

}
