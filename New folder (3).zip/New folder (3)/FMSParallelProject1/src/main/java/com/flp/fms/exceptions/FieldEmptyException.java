package com.flp.fms.exceptions;

public class FieldEmptyException extends Exception {

}
