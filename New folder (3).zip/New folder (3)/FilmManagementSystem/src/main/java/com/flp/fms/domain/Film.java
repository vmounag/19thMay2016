package com.flp.fms.domain;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Film {
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(nullable=false)
	private int film_id;

	
	

	@Column(nullable=false)
	private String title;
	
	@Column(nullable=false)
	private String Description;
	

    @Column(nullable=false)
	@Temporal(TemporalType.DATE)
    private Date release_year;
	

    @ManyToOne(cascade={CascadeType.ALL})
    @JoinColumn(name="language_id")
	private Language language;
	
    
    @Column(nullable=false)
     private short rental_duration;
    
    
    @Column(nullable=false)
    private short rental_rate;
    
    
    @Column(nullable=false)
    private int length;
    
    @Column(nullable=false)
    private BigInteger replacement_cost;
    
    @Column(nullable=false)
    private String rating;
    
    @Column(nullable=false)
    private String special_features;
    
    @ManyToMany(cascade={CascadeType.ALL})
    @JoinTable(name="film_actor" ,joinColumns=@JoinColumn(name="film_id",referencedColumnName="film_id"),inverseJoinColumns=@JoinColumn(name="actor_id",referencedColumnName="actor_id"))
      private Set<Actor> actors=new HashSet();  
	
	
	
    @ManyToOne(cascade = {CascadeType.ALL})
	@JoinTable(name = "film_category", joinColumns = @JoinColumn(name = "film_id", referencedColumnName = "film_id") , inverseJoinColumns = @JoinColumn(name = "category_id", referencedColumnName = "category_id"))
	private Category category;
	
	
    @Column(nullable=true,columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@Temporal(TemporalType.TIMESTAMP)
	private Date last_update;
    
    public int getFilm_id() {
		return film_id;
	}


	public void setFilm_id(int film_id) {
		this.film_id = film_id;
	}



	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getDescription() {
		return Description;
	}


	public void setDescription(String description) {
		Description = description;
	}


	public Date getRelease_year() {
		return release_year;
	}


	public void setRelease_year(Date release_year) {
		this.release_year = release_year;
	}


	public Language getLanguage() {
		return language;
	}


	public void setLanguage(Language language) {
		this.language = language;
	}


	public short getRental_duration() {
		return rental_duration;
	}


	public void setRental_duration(short rental_duration) {
		this.rental_duration = rental_duration;
	}


	public short getRental_rate() {
		return rental_rate;
	}


	public void setRental_rate(short rental_rate) {
		this.rental_rate=rental_rate;
	}


	public int getLength() {
		return length;
	}


	public void setLength(int length) {
		this.length = length;
	}


	public BigInteger getReplacement_cost() {
		return replacement_cost;
	}


	public void setReplacement_cost(BigInteger replacement_cost) {
		this.replacement_cost = replacement_cost;
	}


	public String getRating() {
		return rating;
	}


	public void setRating(String rating) {
		this.rating = rating;
	}


	public String getSpecial_features() {
		return special_features;
	}


	public void setSpecial_features(String special_features) {
		this.special_features = special_features;
	}


	public Set<Actor> getActors() {
		return actors;
	}


	public void setActors(Set<Actor> actors) {
		this.actors = actors;
	}


	public Category getCategory() {
		return category;
	}


	public void setCategory(Category category) {
		this.category = category;
	}


	public Date getLast_update() {
		return last_update;
	}


	public void setLast_update(Date last_update) {
		this.last_update = last_update;
	}


	@Override
	public String toString() {
		return "Film [film_id=" + film_id + ", title=" + title + ", Description=" + Description + ", release_year="
				+ release_year + ", language=" + language + ", rental_duration=" + rental_duration + ", rental_rate="
				+ rental_rate + ", length=" + length + ", replacement_cost=" + replacement_cost + ", rating=" + rating
				+ ", special_features=" + special_features + ", actors=" + actors + ", category=" + category
				+ ", last_update=" + last_update + "]";
	}


	public Film() {
		super();
		
	}


	
	
	
	
	
	
	
	
	
}
