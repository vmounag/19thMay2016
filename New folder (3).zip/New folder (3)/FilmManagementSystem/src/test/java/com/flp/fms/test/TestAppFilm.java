package com.flp.fms.test;

import junit.framework.TestCase;

public class TestAppFilm extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}
                                                  
	
	
	
	
	
	
	
	
	
	
}
