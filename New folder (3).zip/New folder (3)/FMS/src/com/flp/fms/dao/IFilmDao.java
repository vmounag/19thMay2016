package com.flp.fms.dao;

public interface IFilmDao {

}
