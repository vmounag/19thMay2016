package com.flp.fms.dao;

public class ActorDaoImplForList {

}
