package com.flp.fms.dao;

public class FilmDaoImplForList implements IFilmDao {

}
