package com.flp.fms.service;

import java.util.List;

import com.flp.fms.domain.Actor;

public interface IActorService {
Actor AddActor(String firstname,String lastname);
Actor modifyActor(short actor_id,String firstname,String lastname);
boolean removeActor(short actor_id);
Actor searchFilm(int actor_id);
List<Actor> getAllActor();

}
