package com.flp.fms.service;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.List;

import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Film;

import java.text.ParseException;

public class FilmServiceImpl implements IFilmService {

	IFilmDao filmdao;
	public FilmServiceImpl()
	{
		filmdao=new FilmDaoImplForList();
	}
	
	public void  AddFilm(List filmList) throws ParseException
	{
		
		Film film=new Film();
		film.setTitle((String) filmList.get(0));
		film.setDescription((String) filmList.get(1));
		film.setRelease_year((Date)filmList.get(2));
		film.setRental_duration((BigDecimal) filmList.get(3));
		film.setRental_rate((short)filmList.get(4));
	   film.setLength((int) filmList.get(5));
		film.setReplacement_cost((BigDecimal) filmList.get(6));
		film.setRating((String) filmList.get(7));
		film.setSpecial_features((String)filmList.get(8));
		
		
		
	}
	
	
	public void modifyFilm()
	{
		
		
		
		
		
		
		
	}
	
	public boolean removeFilm(short film_id)
	{
		
		
		
		
		
		return true;
		
		
		
		
	}
	
	
public	Film searchFilm(short film_id)
	{
		
		
		
		return 
		
	}
	
	
	
public List<Film> getAllFilm()
{
	
	
	
	
	
	
	return 
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
