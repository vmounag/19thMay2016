package com.flp.fms.service;

import java.text.ParseException;
import java.util.List;

import com.flp.fms.domain.Film;

public interface IFilmService {
public void  AddFilm(List filmList) throws ParseException;
public void modifyFilm();
public boolean removeFilm(short film_id);
Film searchFilm(short film_id);
List<Film> getAllFilm();



}
