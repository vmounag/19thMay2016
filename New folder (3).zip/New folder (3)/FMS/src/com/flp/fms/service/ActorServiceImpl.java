package com.flp.fms.service;

public class ActorServiceImpl implements IActorService {

}
