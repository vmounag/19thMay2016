package com.flp.fms.domain;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Category {
	@Id @GeneratedValue(strategy=GeneratedTyped.Auto)
	
	@Coloumn(nullable==false)
	private String name;
	
	@Column(insertable = false, updatable = false,nullable=false,columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
	@Temporal(TemporalType.TIMESTAMP)
	private Date last_update;
	@OnetoMany(mappedBy="category")
	private Set<Film> films=new HashSet();
	public Category(String name, Date last_update, Set<Film> films) {
		super();
		this.name = name;
		this.last_update = last_update;
		this.films = films;
	}
	@Override
	public String toString() {
		return "Category [name=" + name + ", last_update=" + last_update + ", films=" + films + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getLast_update() {
		return last_update;
	}
	public void setLast_update(Date last_update) {
		this.last_update = last_update;
	}
	public Set<Film> getFilms() {
		return films;
	}
	public void setFilms(Set<Film> films) {
		this.films = films;
	}
}
