package com.flp.fms.domain;

import java.util.HashSet;
import java.util.Set;

@Entity
public class Actor {
@Id @GeneratedValue(strategy=GeneratedTyped.Auto)

@Coloumn(nullable==false)
private String first_name;

@Coloumn(nullable==false)
private String last_name;

@Column(insertable = false, updatable = false,nullable=false,columnDefinition="TIMESTAMP DEFAULT CURRENT_TIMESTAMP")
@Temporal(TemporalType.TIMESTAMP)
private Date last_update;
@Manyto@Many(mappedBy="actors")
private Set<Film> films=new HashSet();
public Actor(String first_name, String last_name, Date last_update, Set<Film> films) {
	super();
	this.first_name = first_name;
	this.last_name = last_name;
	this.last_update = last_update;
	this.films = films;
}
@Override
public String toString() {
	return "Actor [first_name=" + first_name + ", last_name=" + last_name + ", films=" + films + "]";
}
public String getFirst_name() {
	return first_name;
}
public void setFirst_name(String first_name) {
	this.first_name = first_name;
}
public String getLast_name() {
	return last_name;
}
public void setLast_name(String last_name) {
	this.last_name = last_name;
}
public Date getLast_update() {
	return last_update;
}
public void setLast_update(Date last_update) {
	this.last_update = last_update;
}
public Set<Film> getFilms() {
	return films;
}
public void setFilms(Set<Film> films) {
	this.films = films;
}


}
