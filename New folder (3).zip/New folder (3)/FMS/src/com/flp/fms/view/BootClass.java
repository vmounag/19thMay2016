package com.flp.fms.view;

import java.util.Scanner;



public class BootClass {
	
	 UserInteraction ui= new UserInteraction();
	private static Scanner sc=new Scanner(System.in);
	public static void main(String[] args) {
	
		
		
			menuSelection();

	}
	

		private static void menuSelection() {
			
			int choice;
			while(true)
			{
				System.out.println("Menu");
				System.out.println("1.Add film");
				System.out.println("2.Modify film");
				System.out.println("3.Remove film");
				System.out.println("4.Search film");
				System.out.println("5.GetAll film");
				System.out.println("6.Add Actor");
				System.out.println("7.Modify Actor");
				System.out.println("8.Remove Actor");
				System.out.println("9.Search Actor");
				System.out.println("10.GetAll Actor");
				System.out.println("11.Exit");
				System.out.println("Enter your choice");
				choice=sc.nextInt();
				switch(choice)
				{
				case 1:
				       ui.AddFilm();
				     
				       break;
				case 2: ui.modifyFilm();
				case 3:ui.removeFilm();
				       
				       break;
				case 4:
			           ui.serachFilm();
			          
			           break; 
				case 5:ui.getAllFilm();
				       break;
				case 6:ui.AddActor();
				       break;
				case 7:ui.modifyFilm();
				       break;
				case 8:ui.removeActor();
				       break;
				case 9:ui.searchActor();
				       break;
				case 10:ui.getAllActors();
				       break;
				case 11:system.exit();
				       break;
				       
				}
			}
			
			}
}
				       
				       
	



