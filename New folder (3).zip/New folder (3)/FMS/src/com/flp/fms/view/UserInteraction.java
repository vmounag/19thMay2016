package com.flp.fms.view;
import java.awt.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class UserInteraction {
	Scanner sc=new Scanner(System.in);
	IFilmService filmservice;
	IActorService actorservice;
	public UserInteraction()
	{
		filmservice= new FilmServiceImpl();
	 actorservice= new ActorServiceImpl();
	}	
	
	public void addFilm() throws ParseException
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		ArrayList filmlist=new ArrayList();
		System.out.println("enter film title");
		filmlist.add(sc.next());
		System.out.println("enter description");
		filmlist.add(sc.next());
		System.out.println("enter release year");
		filmlist.add(dateFormat.parse(sc.next()));
		System.out.println("enter rental duration");
		filmlist.add(sc.nextShort());
		System.out.println("enter rental rate");
		filmlist.add(sc.nextShort());
		System.out.println("enter length");
		filmlist.add(sc.nextShort());
		System.out.println("enter replacementcost");
		filmlist.add(sc.nextBigInteger());
		System.out.println("enter rating");
		filmlist.add(sc.next());
		System.out.println("enter special features");
		filmlist.add(sc.next());
		System.out.println("enter language");
		filmlist.add(sc.next());
		System.out.println("enter category");
		filmlist.add(sc.next());
		System.out.println("enter number of actors");
		int numofactors=sc.nextInt();
		
		for(int i=0;i<=numofactors;i++)
		{   ArrayList actorDetails=new ArrayList();
			System.out.println("enter firstname of actor");
		actorDetails.add(sc.next());
		System.out.println("enter lastname of actor");
		actorDetails.add(sc.next());
		filmlist.add(actorDetails);
		}
		
		 filmservice.AddFilm(filmlist);
		 public void modifyFilm()
		 {
			 
		 }
		public void removeFilm()
		{
			System.out.println("Enter the film id to remove");
			short film_id=sc.nextShort();
			if(filmservice.removeFilm(film_id))
			{
				System.out.println("film Successfully removed");
			}
			else
			{
				System.out.println("film Not Found");
			}
		}
		public void searchFilm()
		{
			System.out.println("search film by film id");
			short film_id=sc.nextShort();
			Film film=filmservice.searchFilm(film_id);
			if(film !=null)
			{
				System.out.println("found "+film);
			}
			else
				System.out.println("not found");
		}	
		public void getAllFilm()
		{
			List<Film> films=filmservice.getAllFilm();
			System.out.println("all films are "+films);
		}
		public void AddActor()
		{
			Actor actor=new Actor();
			System.out.println("enter first name");
			String firstname=sc.next();
			System.out.println("enter last name");
			String lastname=sc.next();
			return actorservice.AddActor(firstname,lastname);
		}
		public void modifyActor()
		{
			System.out.println("enter actor id that shoulb be modified");
			int actor_id=sc.nextInt();
			System.out.println("enter first name");
			String firstname=sc.next();
			System.out.println("enter last name");
			String lastname=sc.next();
			System.out.println("modified actor details are "+actorservice.modifyActor(actor_id,firstname,lastname));
		}
		public void searchActor()
		{    
			System.out.println("enter the actor id that should be retrievd");
			int actor_id=sc.nextInt();
			Actor actors=actorservice.SearchActor(actor_id);
			if(actors !=null)
			{
				System.out.println("Found "+actors);
			}
			else
			{
				System.out.println("Not Found");
			}
		}
			
		public void removeActor()
		{
			System.out.println("enter actor id that should be removed");
			int actor_id=sc.nextInt();
			if(actorservice.removeActor(actor_id))
			{
				System.out.println("actor details removed sucessfully");
			}
			else System.out.println("cannot be removed");
				
		}
		public void getAllActor()
		{
			List<Actor> actors=actorservice.getAllActor();
			System.out.println("all actor details "+actors);
		}
			
		
	}
	}
		
	


