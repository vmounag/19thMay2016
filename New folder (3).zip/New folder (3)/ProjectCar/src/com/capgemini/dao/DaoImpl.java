package com.capgemini.dao;

public class DaoImpl implements IDao {

	
	
	
	
	
	
	
	
}
