var app=angular.module('myApp',[]);
appValue("count",100);
appConstant("pi",3.14);