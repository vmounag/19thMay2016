
public class Accounts {
	 
	    private int accountNumber;
	 	private double balance;
	  public void setAccountNumber(int i)
	  {
	 	 accountNumber=i;
	 	System.out.println(accountNumber);
	  }
	  public void setBalance(int i)
	  {
		
		  balance=i*10;
		  
	 
	 System.out.println(balance);
	  
	  }
	  public int getAccountNumber()
	  {
	 	return accountNumber;
	 	
	  }
	  public double getBalance()
	  {
	   return balance;
	  }
	  }


