class Account
{
int accountNumber;
double balance;
}
public class AccountTest
{
	public static void main(String args[])
	{
	Account a1=new Account();
	 a1.accountNumber=1;
	a1.balance=5000;
	System.out.println(a1.accountNumber);
System.out.println(a1.balance);
	}
}
