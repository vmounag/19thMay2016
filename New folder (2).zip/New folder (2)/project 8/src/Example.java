
public class Example {
	public static void main(String args[ ])
	{
		int d=2;
		byte c=8;
		byte e=a+d;
		int a= c+d;
		
	System.out.println(e);
	}


}
