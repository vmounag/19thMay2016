public class Excep{
	public static void main(String[] args) {
		try
		{
		int a=10;
		int b=0;
		int ans=a/b;
		}catch(ArithmeticException ae)
		{
		
		System.out.println("divide by zero");
	}
		try
		
		{
			int[] array={2,4};
			System.out.println(array[5]);
				
		}catch(ArrayIndexOutOfBoundsException ie)
		{
			System.out.println("out of bounds");
		}
	
      try
         {
		String s=null;
		System.out.println(s.length());
         }catch(NullPointerException ne)
         {
        	 System.out.println("null exception");
         }
	
finally
	{
	System.out.println("getlost");
	
	}
	}

	}
