class Arg
{
public static void main(String args[ ])

{

    int i = args.length-1;

   if (i > 0) System.out.println(args[i]);

}

}
