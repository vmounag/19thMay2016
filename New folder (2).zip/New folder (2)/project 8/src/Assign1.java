import java.io.*;
public class Assign1 {
	public static void main(String args[])
	{
		int a;
		double d;
		float f;
		char ch;
		boolean x;
		byte b;
		long l;

	System.out.println("default value of="+a+d+f+xb+l);
	}
	}


