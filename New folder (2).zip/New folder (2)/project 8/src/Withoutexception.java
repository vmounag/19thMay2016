
public class Withoutexception {
	public static void main(String[] args) {
		try
		{
		int a=10;
		int b=0;
		int ans=a/b;
		}catch(ArithmeticException ae)
		{
		
		System.out.println("divide by zero");
	}

}
}