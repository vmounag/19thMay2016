import java.util.Scanner;

public class TestArray {
	

	public static void main(String[] args) {
		Scanner sc=new Scanner();
		System.out.println("number of students");
		int num=sc.nextInt();
		Student[] s=new Student[num];
		for(int i=0;i<num;i++)
		{
			Student[i]=new Student();
			System.out.println("giv id numbers");
			int id=sc.nextInt();
			Student[i].setId(id);
			System.out.println("give names");
			String name=sc.next();
			Student[i].setName(name);
			
		}
			
		
		for( int i=0;i<num;i++)
		{
		System.out.println(Student[i].getId());
		System.out.println(Student[i].getName());
}

		
	
		
		
		
		

	}

}
