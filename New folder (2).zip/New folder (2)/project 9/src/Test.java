import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		Student s=new Student();
		Scanner sc=new Scanner(System.in);
		
		
		System.out.println("id no is:");
		int id=sc.nextInt();
		s.setId(id);
		System.out.println("name is:");
		String name=sc.next();
		s.setName(name);
		System.out.println("enter number of courses");
        int num=sc.nextInt();
        System.out.println("give course names");
        String[] array=new String[num];
        for(int i=0;i<num;i++)
        {
        	array[i]=sc.next();
        }
        
        s.setCourses(array);
        System.out.println(s.getId());
        System.out.println(s.getName());
        for(int i=0;i<num;i++)
        {
        	System.out.println(s.getCourses()[i]);
        }
        		}

}
