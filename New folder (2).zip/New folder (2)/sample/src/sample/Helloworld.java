package sample;

public class Helloworld {
	public static void main(String arg[])
	{
	System.out.println("Helloworld");
	}}


