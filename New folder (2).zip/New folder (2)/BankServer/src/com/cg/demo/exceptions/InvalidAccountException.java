package com.cg.demo.exceptions;

public class InvalidAccountException extends Exception {

}
