
public class Address {
	private String city;

	public Address(String city) {
		super();
		this.city = city;
	}
	

}
