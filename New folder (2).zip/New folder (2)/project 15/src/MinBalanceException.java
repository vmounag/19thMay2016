
public class MinBalanceException extends Exception{

}
