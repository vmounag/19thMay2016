
public class Customer {
private  Address address;
private String name;
public Customer( String name,Address address) {
	super();
	this.address = address;
	this.name = name;
}
}