 class Plant {
	 public Plant(0)
	 { Tree();
	 
	 }
private String name;
public Plant(String name) { this.name = name; }
public String getName() { return name; }
}
 public class Tree extends Plant {
	
 public void growFruit() { }
 public void dropLeaves() { }
 }
